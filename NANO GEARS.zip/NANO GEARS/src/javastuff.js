function a(target) {
	document.querySelector('.anonymous-link').href = target+'.html';
	document.querySelector('.anonymous-link').click();
}